import time
from machine import Pin
from ButtonStateMachine import StateMachineForButton

#输入脚，PULL_DOWN定义了下拉电阻
#这样在按钮没有按下时管脚保持低电平
buttonPin=Pin(25,Pin.IN,Pin.PULL_DOWN)

#按钮事件回调处理方法
def bnCallBack(isLong,count=0):
    #若为长按事件
    if isLong:
        print("Long push!")
    #若为点击事件(含各种次数的连击)
    else:
        print("Click>",count)


#创建按钮状态机对象
smfb=StateMachineForButton(bnCallBack,buttonPin)

#循环监测按钮情况
while True:
    smfb.doTask()
    time.sleep(0.005)



        

