from machine import Pin
import utime

ledRed=Pin(25,Pin.OUT)
ledGreen=Pin(26,Pin.OUT)
ledYellow=Pin(27,Pin.OUT)

def setLedStatus(sl):
    ledRed.value(sl[0])
    ledGreen.value(sl[1])
    ledYellow.value(sl[2]) 

statusList=[[1,0,0],[0,1,0],[0,0,1],
            [0,1,1],[1,0,1],[1,1,0],
            [1,1,1],[0,0,0]]

while True:
    for currStatus in statusList:
        setLedStatus(currStatus)
        utime.sleep(0.5)


