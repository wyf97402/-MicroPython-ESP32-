import machine
from machine import Pin
from machine import ADC
import utime

adcIn=ADC(Pin(36))
# ADC.ATTN_0DB — 1.2V  默认
# ADC.ATTN_2_5DB — 1.5V
# ADC.ATTN_6DB — 2.0V
# ADC.ATTN_11DB —  3.3V
adcIn.atten(ADC.ATTN_11DB)

while True:
    print(adcIn.read_u16())
    utime.sleep(0.2)

