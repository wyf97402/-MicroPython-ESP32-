from machine import Pin,TouchPad
from time import sleep

#板载LED对应的GPIO
led=Pin(13,Pin.OUT)

#用于电容触控的GPIO
#可选GPIO 4、0、2、15、13、12、14、27、33、32
ecTouchPin=Pin(32,Pin.IN,Pin.PULL_UP)
#创建触控对象
tp=TouchPad(ecTouchPin)

while True:
    #读取触控值
    tValue=tp.read()
    #当触控值小于指定阈值
    if(tValue<100):
        #板载LED亮
        led.value(1)
    else:
        #板载LED灭
        led.value(0)
    #休眠100ms
    sleep(0.1)

