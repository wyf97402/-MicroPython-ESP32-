import esp32
import time
from neopixel import NeoPixel
from machine import Pin

#级联的灯珠总数量
num_leds = 1
#创建像素序列对象
np = NeoPixel(Pin(15), num_leds)
#霍尔传感器读数阈值
HALL_THOLD=150

#设置板载WS2812B灯珠颜色的方法
def setColor(r,g,b):
    np[0]=(r,g,b)
    np.write()

while(True):
    #获取霍尔传感器读数
    hallValue=esp32.hall_sensor()
    print(hallValue)
    #若霍尔传感器读数大于指定阈值
    if(hallValue>HALL_THOLD):
        setColor(0,10,0)
    #若霍尔传感器读数小于指定阈值
    elif(hallValue<-HALL_THOLD):
        setColor(0,0,10)
    #若霍尔传感器读数绝对值小于阈值
    else:
        setColor(0,0,0)
    #休眠100ms
    time.sleep(0.1);



