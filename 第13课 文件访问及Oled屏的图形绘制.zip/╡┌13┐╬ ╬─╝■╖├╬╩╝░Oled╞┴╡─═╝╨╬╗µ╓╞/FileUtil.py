import os
from framebuf import FrameBuffer
import framebuf
import gc

#读文本文件返回字符串
def readTxtFile(fname):
    msgFile=open(fname,"r")
    strData=msgFile.read()
    return strData

#将四个字节组装为整数的方法
def readInt(bytesArray,start):
    result=bytesArray[start]+(bytesArray[start+1]<<8)+(bytesArray[start+2]<<16)+(bytesArray[start+3]<<24)
    return result

#自定义的二值化图类
class BNBinPic(object):
    def __init__(self,w,h,pdata):
        self.width=w;
        self.height=h;
        #图象像素数据对应的帧缓冲
        self.fbuf=FrameBuffer(bytearray(w*h//8), w, h, framebuf.MONO_VLSB)
        #将图象的像素数据绘制入帧缓冲
        self.drawBNbPicToBuf(pdata)
    
    #将图预加载到buffer
    def drawBNbPicToBuf(self,pdata):
        #当前字节
        currByte=pdata[0]
        #当前字节计数器
        byteCount=0
        #当前比特计数器
        bitCount=0
        #当前比特掩码
        bitMask=0b10000000
        #遍历每一行
        for i in range(self.height):
            #此行当前像素位置
            currX=0
            #遍历每一列
            for j in range(self.width):
                #计算当前像素值
                color=(currByte & bitMask)>>(7-bitCount)
                #绘制当前像素
                self.fbuf.pixel(currX,i,color)
                #X坐标右移一格
                currX=currX+1
                #比特掩码右移1位
                bitMask=bitMask>>1
                #比特计数器加1
                bitCount=bitCount+1
                #如果比特计数器等于7且还有下一个字节，则换字节
                if bitCount==8 and byteCount<len(pdata)-1:
                    bitCount=0
                    byteCount=byteCount+1
                    currByte=pdata[byteCount]                    
                    bitMask=0b10000000
    
def loadPics(fname):
    #结果列表
    pics=[]
    #读取文件字节数据
    dataFile=open(fname,"rb")
    bytesData=dataFile.read()
    #字节计数器
    bcount=0
    #首先读出四个字节组装为图集中图的数量
    count=readInt(bytesData,bcount)
    bcount=bcount+4
    #遍历图集中的每一幅图
    for i in range(int(count)):
        #读取当前图片的宽度、高度
        w=readInt(bytesData,int(bcount))
        bcount=bcount+4
        h=readInt(bytesData,int(bcount))
        bcount=bcount+4
        #提取此图片像素数据字节序列
        dataCurr=bytesData[int(bcount):int(bcount+w*h/8)]
        bcount=bcount+w*h/8
        pics.append(BNBinPic(w,h,dataCurr))
    return pics

#加载指定编号文字对应二值图的方法
def getSpecCharBNBinPic(fname,code):
    #读取文件字节数据
    dataFile=open(fname,"rb")
    #bytesData=dataFile.read()
    #图像计数器
    pCount=0
    #字节计数器
    bcount=0
    #首先读出四个字节组装为图集中图的数量
    buf4=dataFile.read(4)
    count=readInt(buf4,0)
    bcount=bcount+4
    #遍历图集中的每一幅图
    for i in range(int(count)):        
        #读取当前图片的宽度、高度
        dataFile.seek(int(bcount))
        buf4=dataFile.read(4)
        w=readInt(buf4,0)
        bcount=bcount+4
        dataFile.seek(int(bcount))
        buf4=dataFile.read(4)
        h=readInt(buf4,0)
        bcount=bcount+4               
        if pCount==code:
            #提取此图片像素数据字节序列
            dataFile.seek(int(bcount))
            bufPD=dataFile.read(int(w*h/8))
            return BNBinPic(w,h,bufPD)        
        bcount=bcount+w*h/8
        pCount=pCount+1
