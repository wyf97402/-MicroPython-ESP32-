import os
import FileUtil as fu
 
#列出所有的文件
print("============================")
print(os.listdir())

#打开并读写msg.txt文件（文本数据）
print("============================")
strData=fu.readTxtFile("msg.txt")
print(strData)

