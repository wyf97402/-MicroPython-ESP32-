from machine import Pin
import machine
import utime
from ssd1306 import SSD1306_I2C
import FileUtil as fu


sda=Pin(25)
scl=Pin(26)
i2c=machine.I2C(0,sda=sda,scl=scl,freq=400000)
oled=SSD1306_I2C(128,64,i2c)
#调整亮度。0最暗，255最亮
oled.contrast(32)

#加载图集
pics=fu.loadPics("gameA.bnbapic")

#绘制地面
for i in range(4):
    for j in range(8):
        oled.blit(pics[5].fbuf,j*16,i*16)
#绘制古井
oled.blit(pics[16].fbuf,20,16)

#112,89,48,94,
#古井夕照
fontfname="font.bnbapic"
oled.blit(fu.getSpecCharBNBinPic(fontfname,112).fbuf,78,10)
oled.blit(fu.getSpecCharBNBinPic(fontfname,89).fbuf,94,10)
oled.blit(fu.getSpecCharBNBinPic(fontfname,48).fbuf,78,26)
oled.blit(fu.getSpecCharBNBinPic(fontfname,76).fbuf,94,26)
    
#显示画面   
oled.show()
