from rotary_irq_esp import RotaryIRQ
import machine
from machine import Pin
import utime
from ssd1306 import SSD1306_I2C

#编码器系列GPIO
EC11_BUTTON=25
EC11_CLK=26
EC11_DATA=27

#编码器步进
EC11_STEP=4
#编码器最小值
EC11_MIN=0
#编码器最大值
EC11_MAX=100/EC11_STEP

#是否绘制进度条边框标志
isDrawProcessBorder=True

#OLED屏幕系列GPIO
sda=Pin(32)
scl=Pin(33)
i2c=machine.I2C(0,sda=sda,scl=scl,freq=400000)
oled=SSD1306_I2C(128,64,i2c)

#绘制进度条值的方法
def drawProcess(process):
    #清屏
    oled.fill(0)
    #绘制进度条边框
    if(isDrawProcessBorder):
        oled.rect(12,27,104,12,1)
    #根据0~100进度值折算绘制宽度
    width=int((104-4)*process/100)
    #绘制进度条填充矩形
    oled.fill_rect(14,29,width,8,1)
    #绘制进度值百分比
    oled.text(str(int(process))+"%",54,17)
    #执行显示
    oled.show()

#创建编码器读懂对象
r = RotaryIRQ(pin_num_clk=EC11_CLK,  #时钟GPIO
              pin_num_dt=EC11_DATA,  #数据GPIO
              min_val=EC11_MIN,      #最小值
              max_val=EC11_MAX,      #最大值
              reverse=False,         #是否反方向增加
              half_step=True,        #是否使用半步模式（体验更流畅）
              range_mode=RotaryIRQ.RANGE_BOUNDED)#RANGE_BOUNDED--越界截取  RANGE_WRAP-越界后从另一端值开始

#设置编码器初始值
r.setValue(50/EC11_STEP)
#编码器按钮对应的Pin
button=Pin(EC11_BUTTON,Pin.IN,Pin.PULL_UP)

#主循环
while True:
    #若编码器按钮按下
    if button.value()==0:
        #是否绘制进度条边框标志置反
        isDrawProcessBorder=not isDrawProcessBorder
        #休眠200ms以防按钮误判连续按下
        utime.sleep(0.2)
    #根据编码器值计算进度值
    process=r.value()*EC11_STEP
    #绘制进度
    drawProcess(process)
    #休眠40ms
    utime.sleep(0.04)

