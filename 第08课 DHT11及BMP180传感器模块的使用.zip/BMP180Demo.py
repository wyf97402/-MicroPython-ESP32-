from bmp180 import BMP180
import machine
from machine import Pin
import utime
from ssd1306 import SSD1306_I2C

#初始化I2C0，服务于OLED屏幕
#初始化I2C0，服务于OLED屏幕
sda=Pin(25)
scl=Pin(26)
i2c=machine.I2C(0,sda=sda,scl=scl,freq=400000)
oled=SSD1306_I2C(128,64,i2c)

#初始化I2C1，服务于BMP180
sda=Pin(27)
scl=Pin(14)
i2c1=machine.I2C(1,sda=sda,scl=scl,freq=100000)
bmp180 = BMP180(i2c1)
bmp180.oversample_sett = 2
#设置大气压基值
bmp180.baseline = 101325

while True:
    #获取温度数据
    temp = bmp180.temperature
    #获取气压数据并换算为标准大气压
    p = bmp180.pressure/101325
    #获取海拔数据
    altitude = bmp180.altitude
    #在OLED屏幕上显示信息
    oled.fill(0)
    oled.text("Temp:"+str(temp),0,0)
    oled.text("Press:"+str(p),0,15)
    oled.text("altitude:"+str(altitude),0,30)
    oled.show()
    utime.sleep(0.2)



