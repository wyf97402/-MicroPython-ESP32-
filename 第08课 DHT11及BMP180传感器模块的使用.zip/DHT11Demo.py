import dht
import machine
from machine import Pin
import utime
from ssd1306 import SSD1306_I2C

#基于指定的GPIO口创建DHT11对象
sensor = dht.DHT11(Pin(27))

#初始化I2C0，服务于OLED屏幕
sda=Pin(25)
scl=Pin(26)
i2c=machine.I2C(0,sda=sda,scl=scl,freq=400000)
oled=SSD1306_I2C(128,64,i2c)

while True:
    #执行测量
    sensor.measure()
    #在OLED屏幕上显示信息
    oled.fill(0)
    oled.text("Temp:"+str(sensor.temperature())+"C",0,0)
    oled.text("Humidity:"+str(sensor.humidity())+"%",0,15)
    oled.show()
    utime.sleep(0.1)
