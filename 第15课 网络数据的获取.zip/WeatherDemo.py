import network
import utime
import urequests
import ujson
from machine import Pin
import machine
from ssd1306 import SSD1306_I2C
import FileUtil as fu

#从天气预报JSON字符串中提取
#天气情况、温度、风向、风力、空气指数的方法
def getInfoFromJSONStr(jsonStr):
    jo=ujson.loads(jsonStr)
    return (jo["wea"],jo["tem"],jo["win"],jo["win_speed"],jo["air"])

#获取文本内容对应自定义字库索引的方法
def getCharIndex(nrStr):
    srcStr="0123456789雨暴大雪到中小阵尘沙连气：接风雷特指有成向云北错多力东功度级质天温.地°冰阴伴夹强冻霾址I重前量P当南扬浮数晴雹出空雾西"
    result=[]
    for i in range(len(nrStr)):
        currChar=nrStr[i]
        currIndex=0
        for cTemp in srcStr:
            if(cTemp==currChar):
                result.append(currIndex)
                break
            currIndex=currIndex+1   
    return result


sda=Pin(25)
scl=Pin(26)
i2c=machine.I2C(0,sda=sda,scl=scl,freq=400000)
oled=SSD1306_I2C(128,64,i2c)
#调整亮度。0最暗，255最亮
oled.contrast(32)

#加载字库图集
pics=fu.loadPics("weather.bnbapic")

station = network.WLAN(network.STA_IF)
while(not station.isconnected()):
    station.active(True)
    try:
        station.connect("wyf001", "1a2b3c4d5e6fabc")
        #清除屏幕
        oled.fill(1)
        #绘制"连接中..."
        oled.blit(pics[20].fbuf,0,16)
        oled.blit(pics[23].fbuf,16,16)
        oled.blit(pics[15].fbuf,32,16)
        oled.blit(pics[43].fbuf,48,16)
        oled.blit(pics[43].fbuf,64,16)
        oled.blit(pics[43].fbuf,80,16)
        oled.invert(1)
        oled.show()
        utime.sleep(5.0)
    except OSError:
        #清除屏幕
        oled.fill(1)
        #绘制"出错重连..."
        oled.blit(pics[60].fbuf,0,16)
        oled.blit(pics[30].fbuf,16,16)
        oled.blit(pics[50].fbuf,32,16)
        oled.blit(pics[22].fbuf,48,16)
        oled.blit(pics[41].fbuf,64,16)
        oled.blit(pics[41].fbuf,80,16)
        oled.blit(pics[41].fbuf,96,16)
        oled.invert(1)
        oled.show()
        utime.sleep(2.0)


#清除屏幕
oled.fill(1)
#绘制"连接成功"
oled.blit(pics[20].fbuf,0,8)
oled.blit(pics[23].fbuf,16,8)
oled.blit(pics[29].fbuf,32,8)
oled.blit(pics[37].fbuf,48,8)
#绘制"IP地址:"
oled.blit(pics[54].fbuf,0,24)
oled.blit(pics[58].fbuf,8,24)
oled.blit(pics[44].fbuf,24,24)
oled.blit(pics[53].fbuf,40,24)
oled.blit(pics[22].fbuf,56,24)
#绘制IP地址值
oled.text(str(station.ifconfig()[0]),0,42,0)
oled.invert(1)
oled.show()
utime.sleep(2.0)

#北京的天气
response = urequests.get("https://www.tianqiapi.com/free/day?appid=44164882&appsecret=gdbO1VkB&city=%E5%8C%97%E4%BA%AC")
jsonStr=response.text
#jsonStr='{"cityid":"101020100","city":"上海","update_time":"15:28","wea":"多云","wea_img":"yun","tem":"17","tem_day":"8","tem_night":"6","win":"东北风","win_speed":"2级","win_meter":"6km\/h","air":"32"}'
response.close()

tqData=getInfoFromJSONStr(jsonStr)

#清除屏幕
oled.fill(1)
#绘制"天气："
oled.blit(pics[41].fbuf,0,0)
oled.blit(pics[21].fbuf,16,0)
oled.blit(pics[22].fbuf,32,0)
#绘制天气内容
indexList=getCharIndex(tqData[0])
for i in range(len(indexList)):
    oled.blit(pics[indexList[i]].fbuf,48+i*16,0)
#绘制"温度："
oled.blit(pics[42].fbuf,0,16)
oled.blit(pics[38].fbuf,16,16)
oled.blit(pics[22].fbuf,32,16)
#绘制温度内容
indexList=getCharIndex(tqData[1])
for i in range(len(indexList)):
    oled.blit(pics[indexList[i]].fbuf,48+i*8,16)
oled.blit(pics[45].fbuf,48+len(indexList)*8,16)
#绘制风向内容
indexList=getCharIndex(tqData[2])
for i in range(len(indexList)):
    oled.blit(pics[indexList[i]].fbuf,i*16,32)
#绘制风力内容
indexList=getCharIndex(tqData[3])
for i in range(len(indexList)):
    oled.blit(pics[indexList[i]].fbuf,16*len(tqData[2])+8+i*16,32)
#绘制"空气质量："
oled.blit(pics[67].fbuf,0,48)
oled.blit(pics[21].fbuf,16,48)
oled.blit(pics[40].fbuf,32,48)
oled.blit(pics[57].fbuf,48,48)
oled.blit(pics[27].fbuf,64,48)
oled.blit(pics[63].fbuf,80,48)
oled.blit(pics[22].fbuf,96,48)
#绘制空气质量指数值
indexList=getCharIndex(tqData[4])
for i in range(len(indexList)):
    oled.blit(pics[indexList[i]].fbuf,104+i*8,48)

oled.invert(1)
oled.show()


