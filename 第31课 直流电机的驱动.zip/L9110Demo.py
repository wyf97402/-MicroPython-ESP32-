from machine import Pin,PWM
import utime

#驱动电机的方法
#aNo,bNo--驱动电机用的两个GPIO口
#ratio 驱动比例0~1(10000-65535)
#此参数值越大电机运行速度越快
#isA是否为aNo实际驱动(可以简单理解为电机正转还是反转)
def driveMotor(aNo,bNo,ratio,isA):
    #根据isA参数确定PWM输出管脚以及
    #低电平输出管脚
    if isA:
        high=PWM(Pin(aNo))
        low=Pin(bNo,Pin.OUT)
    else:
        high=PWM(Pin(bNo))
        low=Pin(aNo,Pin.OUT)
    #设置PWM的频率，此频率不能过高
    #过高电机不能正常驱动
    high.freq(300)
    #设置低电平管脚输出低电平
    low.value(0)
    #根据ratio参数折算占空比
    zkb=int(ratio*55535)+10000
    #当占空比实际值小于30000时大概率
    #电机不能静态启动，因此当实际占空比
    #小于30000时要短时间使用30000来完成
    #静态启动
    if(zkb<30000):
        high.duty_u16(30000)
        utime.sleep(0.03)
    high.duty_u16(zkb)


driveMotor(25,26,0.8,False)
