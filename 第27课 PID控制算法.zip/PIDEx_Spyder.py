import matplotlib as mpl
import matplotlib.pyplot as plt

#设置支持中文(用黑体显示中文)
mpl.rcParams["font.sans-serif"]=["SimHei"]

#目标值
r=1000
#当前值
c=600
#比例部分系数
kp=0.2
#积分部分系数
ki=0.2
#微分部分系数
kd=0.2
#上一次的偏差
ebefore=0
#偏差和
sigmaE=0
#漏水量
fs=50
#最大控制量
umax=300
#时刻序号列表
xl=[]
#控制值列表
ul=[]
#当前值列表
cl=[]

#迭代指定次数
for i in range(1,100):    
    #计算积分部分值
    sigmaE=sigmaE+(r-c)
    #计算控制值
    u=kp*(r-c)+ki*sigmaE+kd*(r-c-ebefore)
    #更新上一次偏差值
    ebefore=r-c
    #若控制值大于最大允许值则限制
    if(u>umax):u=umax
    if(u<-umax):u=-umax
    #计算当前值
    c=c+u-fs
    #在第40和70时刻加入扰动
    if i==40 or i==70:c=500
    #将各项值记录进对应列表
    xl.append(i)
    ul.append(u)
    cl.append(c)
    
    
#目标值参考线
plt.axhline(r,linestyle=":",label="目标值")
#最大控制值参考下
plt.axhline(umax,linestyle="--",label="最大u")
#绘制控制值变化曲线
plt.plot(xl,ul,color="#FF0000",label="u(t)")
#绘制当前值变化曲线
plt.plot(xl,cl,color="#00FF00",label="当前水量")
#在右侧中间显示图例
plt.legend(loc="center right")
#显示图像
plt.show()
#打印各个列表
print(xl)
print(ul)
print(cl)
