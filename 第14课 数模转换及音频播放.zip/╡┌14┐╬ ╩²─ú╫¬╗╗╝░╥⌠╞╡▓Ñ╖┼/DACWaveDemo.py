from machine import Pin
from machine import DAC
import utime
from WaveGenUtil import WaveGenerator

dac=DAC(Pin(25))
wg=WaveGenerator(dac)
#wg.jcbGen()
#wg.triGen()
wg.sinGen()
