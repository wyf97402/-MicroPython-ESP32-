from uln2003 import  Command,Stepper,Driver
from uln2003 import  HALF_STEP,FULL_ROTATION

#将角度值转换为步数的方法
def fromAngleToSteps(angle):
    return int(angle*FULL_ROTATION/360)

#创建步进电机驱动对象
#这里使用的是五线四相步进电机
#25，26，27，14为步进电机的四根驱动信号线
#delay为每步多少秒
s1 = Stepper(HALF_STEP, 25, 26, 27, 14, delay=0.00125)
#执行旋转
#第一个参数为总步数 第二个参数为方向（-1表示逆时针，1表示顺时针）
#s1.step(fromAngleToSteps(45),1)

#创建Driver对象，通过其可以驱动多个步进电机
runner = Driver()
#执行命令，参数为命令列表
#每个命令创建时3个参数，依次为步进电机驱动对象、步数、方向
runner.run([Command(s1, fromAngleToSteps(30), -1)])
