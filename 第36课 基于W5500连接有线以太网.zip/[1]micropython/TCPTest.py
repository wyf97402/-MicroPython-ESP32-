from wiznet5k import WIZNET5K
from machine import Pin, SPI
import wiznet5k_socket as socket
import sma_esp32_w5500_requests as requests
import time

#服务于W5500有线以太网的SPI
spi=SPI(2,baudrate=8000000,sck=Pin(25),mosi=Pin(26),miso=Pin(27))
#CS对应的GPIO
cs = Pin(5,Pin.OUT)
#虚指GPIO 实际接高电平即可
rst=Pin(39)

#创建W55XX驱动对象
nic = WIZNET5K(spi,cs,rst)
#打印相关信息
print("\n\n以太网芯片版本:", nic.chip)
print("网卡MAC地址:", [hex(i) for i in nic.mac_address])
print("IP地址:", nic.pretty_ip(nic.ip_address))

#创建tcp套接字
tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#连接指定IP的服务器上的指定端口
tcp_socket.connect(("192.168.8.100",8080))

#发送给服务器的数据
msg="Hello Server!"
#发送字符串字节数据
tcp_socket.send(msg.encode('utf-8'))

#不断循环接收服务器消息
while(True):    
    #收字符串信息字节序列
    dataBytes=tcp_socket.recv(12)
    #打印信息
    print(dataBytes)
    print(dataBytes.decode('utf-8')) 




