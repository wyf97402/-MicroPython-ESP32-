from wiznet5k import WIZNET5K
from machine import Pin, SPI
import wiznet5k_socket as socket
import sma_esp32_w5500_requests as requests
import time

#服务于W5500有线以太网的SPI
spi=SPI(2,baudrate=8000000,sck=Pin(25),mosi=Pin(26),miso=Pin(27))
#CS对应的GPIO
cs = Pin(5,Pin.OUT)
#虚指GPIO 实际接高电平即可
rst=Pin(39)

#创建W55XX驱动对象
nic = WIZNET5K(spi,cs,rst)
#打印相关信息
print("\n\n以太网芯片版本:", nic.chip)
print("网卡MAC地址:", [hex(i) for i in nic.mac_address])
print("IP地址:", nic.pretty_ip(nic.ip_address))

#创建udp套接字
udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

#准备接收方的地址
# '192.168.1.103'表示目的ip地址
# 8080表示目的端口
# 注意 是元组，ip是字符串，端口是数字
dest_addr = ('192.168.8.100', 8080)  

#发送数据到指定的电脑上的指定程序中
for i in range(10):
    send_data = "hello world--%d" % i
    udp_socket.sendto(send_data.encode('utf-8'), dest_addr)
    time.sleep(1)

#关闭套接字
udp_socket.close()
