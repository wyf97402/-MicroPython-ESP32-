from machine import Pin,I2C,SoftI2C
from gesture import Gesture
import time

#服务于手势传感器的I2C
i2c=I2C(0,scl=Pin(26), sda=Pin(25), freq=100000)
#创建手势传感器驱动对象
g=Gesture(i2c)

#不同的手势id对应的含义字符串
msgR=["","Forward","Backward","Right","Left","Up","Down","Clockwise","anti-clockwise","Wave"]

#程序主循环
while True:
    #获取当前手势id
    value=g.return_gesture()
    #若id不为0(即不为空手势)
    if value!=0:
        #打印当前手势含义字符串
        print(value,msgR[value])
    #休眠
    time.sleep(0.08)
