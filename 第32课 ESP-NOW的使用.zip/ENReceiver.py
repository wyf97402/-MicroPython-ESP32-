import network
import espnow
import time
from neopixel import NeoPixel
from machine import Pin

#级联的灯珠总数量
num_leds = 1
#创建像素序列对象
np = NeoPixel(Pin(15), num_leds)

#创建收发数据用Wifi
wlan = network.WLAN(network.STA_IF)
print("Self MAC:",str(wlan.config('mac')))
#激活Wifi
wlan.active(True)
#断开连接（防止自动连接上一次成功连接的路由等设备,服务于ESP8266）
wlan.disconnect()   

#创建ESP-NOW对象
e = espnow.ESPNow()
#激活ESP-NOW
e.active(True)
#发送方的MAC地址
peer = b'\x9c\x9c\x1f\x1aD\xf8'   
e.add_peer(peer)

#设置板载WS2812B为关闭状态
np[0]=(0,0,0)        
np.write()

#循环接收指令并处理执行
while True:
    #接收消息
    host, msg = e.recv()
    #若收到了消息
    if msg:
        #打印消息和发送方MAC地址
        print("Sender MAC>",host, "CMD>",msg)
        #若收到RED指令
        if msg == b'RED':
            np[0]=(6,0,0)        
            np.write()
        #若收到GREEN指令
        elif msg == b'GREEN':
            np[0]=(0,6,0)        
            np.write()
        #若收到BLUE指令
        elif msg == b'BLUE':
            np[0]=(0,0,6)        
            np.write()
        #若收到OFF指令
        elif msg == b'OFF':
            np[0]=(0,0,0)        
            np.write()
        #回传确认消息
        e.send(peer,b'CMD DONE',True)
