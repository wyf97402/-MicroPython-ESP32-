import network
import espnow
import machine
import time
from machine import Pin,ADC
import BNADKeyboard as bnkd

#初始化用于AD键盘
adcIn=machine.ADC(Pin(33))
adcIn.atten(ADC.ATTN_11DB)

#创建收发数据用Wifi
wlan = network.WLAN(network.STA_IF)
#打印自身的MAC
print("Self Mac:",wlan.config('mac'))
#激活Wifi
wlan.active(True)
#断开连接（防止自动连接上一次成功连接的路由等设备,服务于ESP8266）
wlan.disconnect()   

#创建ESP-NOW对象
e = espnow.ESPNow()
#激活ESP-NOW
e.active(True)
#接收方的MAC地址列表
peerList=[b'$\xd7\xebi\xaa\x08',b'\xc4O3\x17E\xb1']
#添加所有的接收方
for peer in peerList:
    e.add_peer(peer)

#不断循环处理按键事件
while True:
    #获取键码
    kc=bnkd.keyCode(adcIn)
    #指令字符串
    cmd=""
    #若按下上键
    if kc==0:
        cmd="RED"
    #若按下左键
    elif kc==1:
        cmd="GREEN"
    #若按下下键
    elif kc==2:
        cmd="BLUE"
    #若按下右键
    elif kc==3:
        cmd="OFF"
    #若指令不为空
    if cmd!="":
        #遍历接收方列表
        for peer in peerList:
            #向每一个接收方发送指令
            e.send(peer, cmd, True)
        #打印指令
        print("CMD>",cmd)
        #接收回传消息
        _,msg = e.recv()
        while not msg:
            _,msg = e.recv()
        #打印回传消息
        print("Back>",msg)
        #休眠200ms防止连按
        time.sleep(0.2)
    #每100ms扫描一次按键状态
    time.sleep(0.1)




